There are two main types of folders:

1-Metaoptimization

2-Results_evaluation


Metaoptimization:
 
This is actually the code of our framework. You just have to open the main file from this folder and then write the algorithm number  in main like 1,2 guidance for algorithm number is provided in main file.

Results_evaluation:
This folder include the files through which any one can verify the results reported in paper. Anyone just have to open the main file and write the function type(unimodal_fixed dimension=1,unimodal_variable dimension=2,multimodal_fixed dimension=3,multimodal_variable dimension=4 ) and algorithm name(WOA1,CSA1,etc)

***Tuned Importance of each equation of each algorithm is provided explicitly in "Equations Optimized Importance Values" excel file.
