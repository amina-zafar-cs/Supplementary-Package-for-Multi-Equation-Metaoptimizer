%_______________________________________________________________________________________%
%  Aquila Optimizer (AO) source codes (version 1.0)                                     %
%                                                                                       %
%  Developed in MATLAB R2015a (7.13)                                                    %
%  Author and programmer:                                                               %
%  Abualigah, L, Yousri, D, Abd Elaziz, M, Ewees, A, Al-qaness, M, Gandomi, A.          %
%         e-Mail: Aligah.2020@gmail.com      (Laith Abualigah)                          %
%       Homepage:                                                                       %
%         1- https://scholar.google.com/citations?user=39g8fyoAAAAJ&hl=en               %
%         2- https://www.researchgate.net/profile/Laith_Abualigah                       %
%                                                                                       %
%   Main paper:                                                                         %
%_____________Aquila Optimizer: A novel meta-heuristic optimization algorithm___________%
%_______________________________________________________________________________________%
% Abualigah, L, Yousri, D, Abd Elaziz, M, Ewees, A, Al-qaness, M, Gandomi, A. (2021). 
% Aquila Optimizer: A novel meta-heuristic optimization algorithm. 
% Computers & Industrial Engineering.
%_______________________________________________________________________________________%
function [Best_FF,Best_P,conv]=AO1(N,T,LB,UB,Dim,F_obj,p1,p2,p3)
phaseone_percentage=zeros(1,4);
phasetwo_percentage=zeros(1,4);
phasethree_percentage=zeros(1,4);
phaseone_percentage(1,:)=p1(1,:);
phasetwo_percentage(1,:)=p2(1,:);
phasethree_percentage(1,:)=p3(1,:);
%   phaseone_percentage=[ 99.50889	43.1543	6.290522	76.89709];
% % % 
%   phasetwo_percentage=[64.65902	63.69214	51.32705	51.78019];
%  phasethree_percentage=[73.56749	12.40522	18.89918	43.81089];

phaseone_acc_pro=calculate(phaseone_percentage);
phasetwo_acc_pro=calculate(phasetwo_percentage);
phasethree_acc_pro=calculate(phasethree_percentage);
Best_P=zeros(1,Dim);
Best_FF=inf;


X=initialization(N,Dim,UB,LB);
Xnew=X;
Ffun=zeros(1,size(X,1));
Ffun_new=zeros(1,size(Xnew,1));

t=1;


alpha=0.1;
delta=0.1;

while t<T+1
    for i=1:size(X,1)
        F_UB=X(i,:)>UB;
        F_LB=X(i,:)<LB;
        X(i,:)=(X(i,:).*(~(F_UB+F_LB)))+UB.*F_UB+LB.*F_LB;
        Ffun(1,i)=F_obj(X(i,:));
        if Ffun(1,i)<Best_FF
            Best_FF=Ffun(1,i);
            Best_P=X(i,:);
        end
    end
    
    
    G2=2*rand()-1; % Eq. (16)
    G1=2*(1-(t/T));  % Eq. (17)
    to = 1:Dim;
    u = .0265;
    r0 = 10;
    r = r0 +u*to;
    omega = .005;
    phi0 = 3*pi/2;
    phi = -omega*to+phi0;
    x = r .* sin(phi);  % Eq. (9)
    y = r .* cos(phi); % Eq. (10)
    QF=t^((2*rand()-1)/(1-T)^2); % Eq. (15)
        %-------------------------------------------------------------------------------------
    for i=1:size(X,1)
        %-------------------------------------------------------------------------------------
        if t<=T/3                  %% Phase 1
          random_num=rand();
           if random_num<phaseone_acc_pro(1,1)
                Xnew(i,:)=Best_P(1,:)*(1-t/T)+(mean(X(i,:))-Best_P(1,:))*rand(); % Eq. (3) and Eq. (4)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
             elseif random_num>phaseone_acc_pro(1,1) &&random_num<phaseone_acc_pro(1,2)
                %-------------------------------------------------------------------------------------
                Xnew(i,:)=Best_P(1,:).*Levy(Dim)+X((floor(N*rand()+1)),:)+(y-x)*rand;       % Eq. (5)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
%             end
            %-------------------------------------------------------------------------------------
       elseif random_num>phaseone_acc_pro(1,2) &&random_num<phaseone_acc_pro(1,3)
           
                Xnew(i,:)=(Best_P(1,:)-mean(X))*alpha-rand+((UB-LB)*rand+LB)*delta;   % Eq. (13)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
           elseif random_num>phaseone_acc_pro(1,3) &&random_num<phaseone_acc_pro(1,4)
                %-------------------------------------------------------------------------------------
                Xnew(i,:)=QF*Best_P(1,:)-(G2*X(i,:)*rand)-G1.*Levy(Dim)+rand*G2; % Eq. (14)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
           end
          elseif t>T/3 && t<2*T/3               %% Phase 2
              random_num=rand();
           if random_num<phasetwo_acc_pro(1,1)
                Xnew(i,:)=Best_P(1,:)*(1-t/T)+(mean(X(i,:))-Best_P(1,:))*rand(); % Eq. (3) and Eq. (4)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
             elseif random_num>phasetwo_acc_pro(1,1) &&random_num<phasetwo_acc_pro(1,2)
                %-------------------------------------------------------------------------------------
                Xnew(i,:)=Best_P(1,:).*Levy(Dim)+X((floor(N*rand()+1)),:)+(y-x)*rand;       % Eq. (5)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
%             end
            %-------------------------------------------------------------------------------------
       elseif random_num>phasetwo_acc_pro(1,2) &&random_num<phasetwo_acc_pro(1,3)
           
                Xnew(i,:)=(Best_P(1,:)-mean(X))*alpha-rand+((UB-LB)*rand+LB)*delta;   % Eq. (13)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
           elseif random_num>phasetwo_acc_pro(1,3) &&random_num<phasetwo_acc_pro(1,4)
                %-------------------------------------------------------------------------------------
                Xnew(i,:)=QF*Best_P(1,:)-(G2*X(i,:)*rand)-G1.*Levy(Dim)+rand*G2; % Eq. (14)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
           end
        else                %%Phase 3
            random_num=rand();
           if random_num<phasethree_acc_pro(1,1)
                Xnew(i,:)=Best_P(1,:)*(1-t/T)+(mean(X(i,:))-Best_P(1,:))*rand(); % Eq. (3) and Eq. (4)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
             elseif random_num>phasethree_acc_pro(1,1) &&random_num<phasethree_acc_pro(1,2)
                %-------------------------------------------------------------------------------------
                Xnew(i,:)=Best_P(1,:).*Levy(Dim)+X((floor(N*rand()+1)),:)+(y-x)*rand;       % Eq. (5)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
%             end
            %-------------------------------------------------------------------------------------
       elseif random_num>phasethree_acc_pro(1,2) &&random_num<phasethree_acc_pro(1,3)
           
                Xnew(i,:)=(Best_P(1,:)-mean(X))*alpha-rand+((UB-LB)*rand+LB)*delta;   % Eq. (13)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
           elseif random_num>phasethree_acc_pro(1,3) &&random_num<phasethree_acc_pro(1,4)
                %-------------------------------------------------------------------------------------
                Xnew(i,:)=QF*Best_P(1,:)-(G2*X(i,:)*rand)-G1.*Levy(Dim)+rand*G2; % Eq. (14)
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
           end
        end
    end
    %-------------------------------------------------------------------------------------
%     if mod(t,100)==0
%         display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(Best_FF)]);
%     end
    conv(t)=Best_FF;
    t=t+1;
end
%% To calculate the accumulative probability of equations in particular phase
function accumulative_probability=calculate(percentage)
phase_percentage=percentage;
phase_probability=zeros(1,4);
accumulative_probability=zeros(1,4);
accumulative=0;
for m=1:4
   phase_probability(1,m)= phase_percentage(1,m)/sum(phase_percentage);
end

  
for n=1:4
    accumulative=accumulative+phase_probability(1,n);
    accumulative_probability(1,n)=accumulative;
end
end

end
function o=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;v=randn(1,d);step=u./abs(v).^(1/beta);
o=step;
end


