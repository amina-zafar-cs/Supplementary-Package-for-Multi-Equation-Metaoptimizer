function [lb,ub,dim,fobj] = Funtions_optimal_difference(F)
dim = 30;
switch F

       
    %Schwefel's 2.20
    case 'F1'
        fobj = @F1;
        lb=-100;
        ub=100;
        
    %Schwefel's 2.21
    case 'F2'
        fobj = @F2;
        lb=-100;
        ub=100;
 %Rosenbrock
    case 'F3'
        fobj = @F3;
        lb=-30;
        ub=30;

          %Dixon and Price
    case 'F4'
        fobj = @F4;
        lb=-10;
        ub=10;

         %Periodic
    case 'F5'
        fobj = @F5;
        lb=-10;
        ub=10;
          %Alpine N. 1
    case 'F6'
        fobj = @F6;
        lb=-10;
        ub=10;
         %Styblinski-Tang
    case 'F7'
        fobj = @F7;
        lb=-5;
        ub=5;
         %CEC2017 - 9
    case 'F8'
        fobj = @F8;
        lb=-100;
        ub=100;
        dim=10;
        
    %CEC2017 - 10
    case 'F9'
        fobj = @F9;
        lb=-100;
        ub=100;
        dim=10;
        
    %CEC2017 - 11
    case 'F10'
        fobj = @F10;
        lb=-100;
        ub=100;
        dim=10;

         %CEC2017 - 14
    case 'F11'
        fobj = @F11;
        lb=-100;
        ub=100;
        dim=10;
        
    %CEC2017 - 15
    case 'F12'
        fobj = @F12;
        lb=-100;
        ub=100;
        dim=10;
        
    %CEC2017 - 16
    case 'F13'
        fobj = @F13;
        lb=-100;
        ub=100;
        dim=10;
        
    %CEC2017 - 17
    case 'F14'
        fobj = @F14;
        lb=-100;
        ub=100;
        dim=10;
        
        
end


% F3 - Schwefel 2.20
function o = F1(x)
	o = sum(abs(x), 2);
end

% F4 - Schwefel 2.21
function o = F2(x)
    o = max(abs(x), [], 2);
end
% F9 - Rosenbrock
function o = F3(x)
dim=size(x,2);
o=sum(100*(x(2:dim)-(x(1:dim-1).^2)).^2+(x(1:dim-1)-1).^2);
end
% F11 - Dixon & Price
function o = F4(x)
x1 = x(1);
d = length(x);
term1 = (x1-1)^2;

sum = 0;
for ii = 2:d
	xi = x(ii);
	xold = x(ii-1);
	new = ii * (2*xi^2 - xold)^2;
	sum = sum + new;
end

o = term1 + sum;
end
% F3 - Periodic
function o = F5(x)
    sin2x = sin(x) .^ 2;
    sumx2 = sum(x .^2, 2);
    o = 1 + sum(sin2x, 2) -0.1 * exp(-sumx2);
end
% F5 - Alpine N. 1
function o = F6(x)
     o = sum(abs(x .* sin(x) + 0.1 * x), 2);
end
% F10 - Styblinski-Tang
function o = F7(x)
    n = size(x, 2);
    o = 0;
    for i = 1:n
        o = o + ((x(:, i) .^4) - (16 * x(:, i) .^ 2) + (5 * x(:, i)));
    end
    o = 0.5 * o;
end
% F9
function o = F8(x) 
    o = cec17_func(x',9);
end

% F10
function o = F9(x) 
    o = cec17_func(x',10);
end


% F11
function o = F10(x) 
    o = cec17_func(x',11);
end
% F14
function o = F11(x) 
    o = cec17_func(x',14);
end

% F15
function o = F12(x) 
    o = cec17_func(x',15);
end

% F16
function o = F13(x) 
    o = cec17_func(x',16);
end


% F17
function o = F14(x) 
    o = cec17_func(x',17);
end
end