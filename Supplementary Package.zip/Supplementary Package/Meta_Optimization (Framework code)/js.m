%-----------------------------------------------------------------------------------------------------------------%
%  JS optimizer                                                                                                   %
%  Jellyfish Search Optimizer (JS) source codes demo version 1.0  Developed in MATLAB R2016a                      %
%  Author and programmer:                                                                                         %
%         Professor        Jui-Sheng Chou                                                                         %
%         Ph.D. Candidate  Dinh- Nhat Truong                                                                      %
%  Paper: A Novel Metaheuristic Optimizer Inspired By Behavior of Jellyfish in Ocean,                             %
%         Applied Mathematics and Computation. Computation, Volume 389, 15 January 2021, 125535.                  %
%  DOI:   https://doi.org/10.1016/j.amc.2020.125535                                                               %
%                                     PiM Lab, NTUST, Taipei, Taiwan, July-2020                                   %
%-----------------------------------------------------------------------------------------------------------------%
function [fval,u,fbestvl]=js(nPop,MaxIt,Lb,Ub,nd,CostFunction,p1,p2,p3)

phaseone_percentage=zeros(1,3);
phasetwo_percentage=zeros(1,3);
phasethree_percentage=zeros(1,3);
phaseone_percentage(1,:)=p1(1,:);
phasetwo_percentage(1,:)=p2(1,:);
phasethree_percentage(1,:)=p3(1,:);
%  phaseone_percentage=[23.75312003	13.99501957	59.52752307];
% 
%  phasetwo_percentage=[41.56782643	0.733599957	97.03343728];
%  phasethree_percentage=[43.09049122	6.963929915	76.93435014 ];

phaseone_acc_pro=calculate(phaseone_percentage);
phasetwo_acc_pro=calculate(phasetwo_percentage);
phasethree_acc_pro=calculate(phasethree_percentage);
%% Problem Definition
nVar=nd;                           % Number of Decision Variables
VarSize=[1 nVar];                  % Size of Decision Variables Matrix
if length(Lb)==1
    VarMin=Lb.*ones(1,nd);         % Lower Bound of Variables
    VarMax=Ub.*ones(1,nd);         % Upper Bound of Variables
else
    VarMin=Lb;
    VarMax=Ub;
end
%% AJS Parameters
% MaxIt = para(1);%1000;        % Maximum Number of Iterations
% nPop = para(2);%50;           % Population Size
% initialization using Logistic map using Eq. (18)
popi=initialization(nPop,nd,VarMax,VarMin);
% Evaluate population
for i=1:nPop
    popCost(i) = CostFunction(popi(i,:));
end
%% AJS Main Loop
for it=1:MaxIt
    Meanvl=mean(popi,1);
    [value,index]=sort(popCost);
    BestSol=popi(index(1),:);
    BestCost=popCost(index(1));
    for i=1:nPop
       
        Ar=(1-it*((1)/MaxIt))*(2*rand-1);
     if  it<MaxIt/3                     %%Phase 1
            random_num=rand();
           if random_num<phaseone_acc_pro(1,1)
      
            newsol = popi(i,:)+ rand(VarSize).*(BestSol - 3*rand*Meanvl);

         elseif random_num>phaseone_acc_pro(1,1) &&random_num<phaseone_acc_pro(1,2)
          
                j=i;
                while j==i
                    j=randperm(nPop,1);
                end
                Step = popi(i,:) - popi(j,:);
                if popCost(j) < popCost(i)
                    Step = -Step;
                end
         
                newsol = popi(i,:) + rand(VarSize).*Step;
           else

                newsol = popi(i,:) + 0.1*(VarMax-VarMin)*rand;
           end
     elseif  it>MaxIt/3&&it<2*MaxIt/3              %%Phase 2

   random_num=rand();
           if random_num<phasetwo_acc_pro(1,1)
       
            newsol = popi(i,:)+ rand(VarSize).*(BestSol - 3*rand*Meanvl);

         elseif random_num>phasetwo_acc_pro(1,1) &&random_num<phasetwo_acc_pro(1,2)
         
                j=i;
                while j==i
                    j=randperm(nPop,1);
                end
                Step = popi(i,:) - popi(j,:);
                if popCost(j) < popCost(i)
                    Step = -Step;
                end
            
                newsol = popi(i,:) + rand(VarSize).*Step;
           else

       
                newsol = popi(i,:) + 0.1*(VarMax-VarMin)*rand;
           end
     else                                               %%Phase 3
            random_num=rand();
           if random_num<phasethree_acc_pro(1,1)
      
            newsol = popi(i,:)+ rand(VarSize).*(BestSol - 3*rand*Meanvl);

         elseif random_num>phasethree_acc_pro(1,1) &&random_num<phasethree_acc_pro(1,2)
            %% Moving inside swarm
           
                % Determine direction of jellyfish by Eq. (15)
                j=i;
                while j==i
                    j=randperm(nPop,1);
                end
                Step = popi(i,:) - popi(j,:);
                if popCost(j) < popCost(i)
                    Step = -Step;
                end
            
                newsol = popi(i,:) + rand(VarSize).*Step;
           else
         
        
                newsol = popi(i,:) + 0.1*(VarMax-VarMin)*rand;
           end
        end
          
            newsol = simplebounds(newsol, VarMin,VarMax);
            % Evaluation
            newsolCost = CostFunction(newsol);
            % Comparison
            if newsolCost<popCost(i)
                popi(i,:) = newsol;
                popCost(i)=newsolCost;
                if popCost(i) < BestCost
                    BestCost=popCost(i);
                    BestSol = popi(i,:);
                end
            end
        end
    
    %% Store Record for Current Iteration
    fbestvl(it)=BestCost;

u=BestSol;
fval=fbestvl(it);
NumEval=it*nPop;
end
%% To calculate the accumulative probability of equations in particular phase
function accumulative_probability=calculate(percentage)
phase_percentage=percentage;
phase_probability=zeros(1,3);
accumulative_probability=zeros(1,3);
accumulative=0;
for m=1:3
   phase_probability(1,m)= phase_percentage(1,m)/sum(phase_percentage);
end

  
for n=1:3
    accumulative=accumulative+phase_probability(1,n);
    accumulative_probability(1,n)=accumulative;
end
end


%% This function is for checking boundary by using Eq. 19
function s=simplebounds(s,Lb,Ub)
ns_tmp=s;
I=ns_tmp<Lb;
% Apply to the lower bound
while sum(I)~=0
    ns_tmp(I)=Ub(I)+(ns_tmp(I)-Lb(I));
    I=ns_tmp<Lb;
end
% Apply to the upper bound
J=ns_tmp>Ub;
while sum(J)~=0
    ns_tmp(J)=Lb(J)+(ns_tmp(J)-Ub(J));
    J=ns_tmp>Ub;
end
% Check results
s=ns_tmp;
end
end