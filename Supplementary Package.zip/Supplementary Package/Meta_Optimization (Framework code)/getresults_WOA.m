
function result_stored  =getresults(comb)



p1=zeros(1,3);
p2=zeros(1,3);
p3=zeros(1,3);
p1=comb(1,1:3);
p2=comb(1,4:6);
p3=comb(1,7:9);


              display(['****Search_agent:  ','    ',num2str(p1(1,1)),'    ',num2str(p1(1,2)),'    ',num2str(p1(1,3)),'    ''   ',num2str(p2(1,1)),'    ',num2str(p2(1,2)),'    ',num2str(p2(1,3)),'   ',num2str(p3(1,1)),'    ',num2str(p3(1,2)),'    ',num2str(p3(1,3)),'    ','   ''*****']);

         
           

            SearchAgents_no=35;    % Number of search agents

            
  result_stored=zeros(14,1);
            Max_iteration=1000;
%             for benchmarksType=1:1
%               
%                 if benchmarksType == 1
%                     maxFunc = 7;
%                 elseif benchmarksType == 2
%                     maxFunc = 8;
%                 else
%                     exit;
%                 end
                for fn = 1:14
                    if fn==16
                      penalty= 100000000;
                    elseif fn==17
                          penalty= 1000000;
                    elseif fn==18
                        penalty= 1000000;
                    elseif fn==19
                        penalty= 1000000;
                    end

                    Function_name=strcat('F',num2str(fn));
%                     if benchmarksType == 1
                        [lb,ub,dim,fobj]= Funtions_optimal_difference(Function_name);
%                     elseif benchmarksType == 2
%                         [lb,ub,dim,fobj]=multimodalVariableDim(Function_name);
%                     end
                    runs=1;
                    Best_score_T = zeros(runs,1);
                    Best_pos_T=zeros(runs,dim);
                     for run=1:runs
                    [Best_score,Best_pos,cg_curve]=WOA1(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,p1,p2,p3);
                    % display(['The best optimal value of the objective funciton found by hybrid is \n ', num2str(Best_score)]);
                    Best_score_T(run) = Best_score;
                     end
                      Best_Score_Mean = mean(Best_score_T);
                    display(['Function:  ', num2str(fn),'  ','cost:  ', num2str(  Best_Score_Mean)]);
               result_stored(fn,1)=  Best_Score_Mean;

                end
           
%              startColumn = excelColumn(startColumnIndex);
% 
%            xlRange = [   startColumn '3']; % Create the Excel range string
%            
%            xlswrite('AO1.xlsx', result_stored(:), 'Sheet3', xlRange); % Write data to the specified range
%           startColumnIndex = startColumnIndex + 1;
% 
%             l=l+1;
% 
%         end
%     end
end
%  xlswrite('AO1.xlsx', p1_eq1(:), 'Sheet4', 'B3');
%   xlswrite('AO1.xlsx', p1_eq2(:), 'Sheet4', 'C3');
%     xlswrite('AO1.xlsx', p1_eq3(:), 'Sheet4', 'D3');
%      xlswrite('AO1.xlsx', p1_eq4(:), 'Sheet4', 'E3');
%     xlswrite('AO1.xlsx', p2_eq1(:), 'Sheet4', 'F3');
%      xlswrite('AO1.xlsx', p2_eq2(:), 'Sheet4', 'G3');
%        xlswrite('AO1.xlsx', p2_eq3(:), 'Sheet4', 'H3');
%         xlswrite('AO1.xlsx', p2_eq4(:), 'Sheet4', 'I3');
%        xlswrite('AO1.xlsx', p3_eq1(:), 'Sheet4', 'J3');
%         xlswrite('AO1.xlsx', p3_eq2(:), 'Sheet4', 'K3');
%           xlswrite('AO1.xlsx', p3_eq3(:), 'Sheet4', 'L3');
%            xlswrite('AO1.xlsx', p3_eq4(:), 'Sheet4', 'M3');
% 
% function colLabel = excelColumn(index)
%     if index <= 26
%         colLabel = char('A' + index - 1);
%     elseif index <= 702
%         div = floor((index - 1) / 26);
%         mod = rem(index - 1, 26);
%         colLabel = [char('A' + div - 1), char('A' + mod)];
%     else
%         div1 = floor((index - 703) / 676);
%         div2 = floor(rem(index - 703, 676) / 26);
%         div3 = rem(index - 703, 26);
%         colLabel = [char('A' + div1), char('A' + div2), char('A' + div3 )];
%     end
% end



