%___________________________________________________________________%
%  Snake Optimizer (SO) source codes version 1.0                    %
%                                                                   %
%  Developed in MATLAB R2021b                                       %
%                                                                   %
%  Author and programmer:  Fatma Hashim & Abdelazim G. Hussien      %
%                                                                   %
%         e-Mail: fatma_hashim@h-eng.helwan.edu.eg                  %
%                 abdelazim.hussien@liu.se                          %
%                 aga08@fayoum.edu.eg                               %
%                                                                   %
%                                                                   %
%   Main paper: Fatma Hashim & Abdelazim G. Hussien                 %
%               Knowledge-based Systems                             %
%               in press,                                           %
%               DOI: 10.1016/j.knosys.2022.108320                   %
%                                                                   %
%___________________________________________________________________%
function [ fval] = SO1(N,T,lb,ub, dim,fobj,p1,p2,p3)
%initial 
phaseone_percentage=zeros(1,4);
phasetwo_percentage=zeros(1,4);
phasethree_percentage=zeros(1,4);
%phaseone_percentage(1,:)=p1(1,:);
%phasetwo_percentage(1,:)=p2(1,:);
%phasethree_percentage(1,:)=p3(1,:);
phaseone_percentage=[12.87213126	63.10501438	99.99974969	32.19649235];
% 
 phasetwo_percentage=[12.42145209	0	75.10059605	0];
 phasethree_percentage=[0	81.3162872	74.41709754	6.872735907];

phaseone_acc_pro=calculate(phaseone_percentage);
phasetwo_acc_pro=calculate(phasetwo_percentage);
phasethree_acc_pro=calculate(phasethree_percentage);

                              % Upper limit for variables

vec_flag=[1,-1];
Threshold=0.25;
Thresold2= 0.6;
C1=0.5;
C2=.05;
C3=2;
X=lb+rand(N,dim).*(ub-lb);

lb=ones(1,dim).*(lb);                              % Lower limit for variables
ub=ones(1,dim).*(ub);
for i=1:N
 fitness(i)=feval(fobj,X(i,:));   
end
[GYbest, gbest] = min(fitness);
Xfood = X(gbest,:);
%Diving the swarm into two equal groups males and females
Nm=round(N/2);%eq.(2&3)
Nm
Nf=N-Nm;
Xm=X(1:Nm,:);
Xf=X(Nm+1:N,:);
fitness_m=fitness(1:Nm);
fitness_f=fitness(Nm+1:N);
[fitnessBest_m, gbest1] = min(fitness_m);
Xbest_m = Xm(gbest1,:);
[fitnessBest_f, gbest2] = min(fitness_f);
Xbest_f = Xf(gbest2,:);
for t = 1:T
    Temp=exp(-((t)/T));  %eq.(4)
  Q=C1*exp(((t-T)/(T)));%eq.(5)
    if Q>1        Q=1;    end
    % Exploration Phase (no Food)
% if Q<Threshold
for i=1:N
    if t<=T/3
          random_num=rand();
           if random_num<phaseone_acc_pro(1,1)
   if i<=N/2
        for j=1:1:dim
            rand_leader_index = floor(Nm*rand()+1);
            X_randm = Xm(rand_leader_index, :);
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            Am=exp(-fitness_m(rand_leader_index)/(fitness_m(i)+eps));%eq.(7)
            Xnewm(i,j)=X_randm(j)+Flag*C2*Am*((ub(j)-lb(j))*rand+lb(j));%eq.(6)
        end
   else
        for j=1:1:dim
            nu=round(i/2);
            rand_leader_index = floor(Nf*rand()+1);
            X_randf = Xf(rand_leader_index, :);
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            Af=exp(-fitness_f(rand_leader_index)/(fitness_f(nu)+eps));%eq.(9)
            Xnewf(nu,j)=X_randf(j)+Flag*C2*Af*((ub(j)-lb(j))*rand+lb(j));%eq.(8)
        end
   end
  
          elseif random_num>phaseone_acc_pro(1,1) &&random_num<phaseone_acc_pro(1,2)

       if i<=N/2
      
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            for j=1:1:dim
                Xnewm(i,j)=Xfood(j)+C3*Flag*Temp*rand*(Xfood(j)-Xm(i,j));%eq.(10)
            end
       
       else
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            for j=1:1:dim
                 nu=round(i/2);
                Xnewf(nu,j)=Xfood(j)+Flag*C3*Temp*rand*(Xfood(j)-Xf(nu,j));%eq.(10)
            end
       end
        elseif random_num>phaseone_acc_pro(1,2) &&random_num<phaseone_acc_pro(1,3)
        
  if i<=N/2
                for j=1:1:dim
                    FM=exp(-(fitnessBest_f)/(fitness_m(i)+eps));%eq.(13)
                    Xnewm(i,j)=Xm(i,j) +C3*FM*rand*(Q*Xbest_f(j)-Xm(i,j));%eq.(11)
                    
                end
  else
           
                for j=1:1:dim
                     nu=round(i/2);
                    FF=exp(-(fitnessBest_m)/(fitness_f(nu)+eps));%eq.(14)
                    Xnewf(nu,j)=Xf(nu,j)+C3*FF*rand*(Q*Xbest_m(j)-Xf(nu,j));%eq.(12)
                end
  end   
         elseif random_num>phaseone_acc_pro(1,3) &&random_num<phaseone_acc_pro(1,4)
            if i<N/2
                for j=1:1:dim
                    Mm=exp(-fitness_f(i)/(fitness_m(i)+eps));%eq.(17)
                    Xnewm(i,j)=Xm(i,j) +C3*rand*Mm*(Q*Xf(i,j)-Xm(i,j));%eq.(15
                end
            
            else
                for j=1:1:dim
                     nu=round(i/2);
                    Mf=exp(-fitness_m(nu)/(fitness_f(nu)+eps));%eq.(18)
                    Xnewf(nu,j)=Xf(nu,j) +C3*rand*Mf*(Q*Xm(nu,j)-Xf(nu,j));%eq.(16)
                end
            end
             flag_index = floor(2*rand()+1);
            egg=vec_flag(flag_index);
            if egg==1;
                [GYworst, gworst] = max(fitness_m);
                Xnewm(gworst,:)=lb+rand*(ub-lb);%eq.(19)
                [GYworst, gworst] = max(fitness_f);
                Xnewf(gworst,:)=lb+rand*(ub-lb);%eq.(20)
            end
           end
    elseif t>T/3&&t< 2*t/3
                     random_num=rand();
           if random_num<phasetwo_acc_pro(1,1)
   if i<=N/2
        for j=1:1:dim
            rand_leader_index = floor(Nm*rand()+1);
            X_randm = Xm(rand_leader_index, :);
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            Am=exp(-fitness_m(rand_leader_index)/(fitness_m(i)+eps));%eq.(7)
            Xnewm(i,j)=X_randm(j)+Flag*C2*Am*((ub(j)-lb(j))*rand+lb(j));%eq.(6)
        end
   else
        for j=1:1:dim
             nu=round(i/2);
            rand_leader_index = floor(Nf*rand()+1);
            X_randf = Xf(rand_leader_index, :);
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            Af=exp(-fitness_f(rand_leader_index)/(fitness_f(nu)+eps));%eq.(9)
            Xnewf(nu,j)=X_randf(j)+Flag*C2*Af*((ub(j)-lb(j))*rand+lb(j));%eq.(8)
        end
   end
  
          elseif random_num>phasetwo_acc_pro(1,1) &&random_num<phasetwo_acc_pro(1,2)

       if i<=N/2
      
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            for j=1:1:dim
                Xnewm(i,j)=Xfood(j)+C3*Flag*Temp*rand*(Xfood(j)-Xm(i,j));%eq.(10)
            end
       
       else
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            for j=1:1:dim
                nu=round(i/2);
                Xnewf(nu,j)=Xfood(j)+Flag*C3*Temp*rand*(Xfood(j)-Xf(nu,j));%eq.(10)
            end
       end
        elseif random_num>phasetwo_acc_pro(1,2) &&random_num<phasetwo_acc_pro(1,3)
        
  if i<=N/2
                for j=1:1:dim
                    FM=exp(-(fitnessBest_f)/(fitness_m(i)+eps));%eq.(13)
                    Xnewm(i,j)=Xm(i,j) +C3*FM*rand*(Q*Xbest_f(j)-Xm(i,j));%eq.(11)
                    
                end
  else
           
                for j=1:1:dim
                    nu=round(i/2);
                    FF=exp(-(fitnessBest_m)/(fitness_f(nu)+eps));%eq.(14)
                    Xnewf(nu,j)=Xf(nu,j)+C3*FF*rand*(Q*Xbest_m(j)-Xf(nu,j));%eq.(12)
                end
  end   
         elseif random_num>phasetwo_acc_pro(1,3) &&random_num<phasetwo_acc_pro(1,4)
            if i<N/2
                for j=1:1:dim
                    Mm=exp(-fitness_f(i)/(fitness_m(i)+eps));%eq.(17)
                    Xnewm(i,j)=Xm(i,j) +C3*rand*Mm*(Q*Xf(i,j)-Xm(i,j));%eq.(15
                end
            
            else
                for j=1:1:dim
                    nu=round(i/2);
                    Mf=exp(-fitness_m(nu)/(fitness_f(nu)+eps));%eq.(18)
                    Xnewf(nu,j)=Xf(nu,j) +C3*rand*Mf*(Q*Xm(nu,j)-Xf(nu,j));%eq.(16)
                end
            end
             flag_index = floor(2*rand()+1);
            egg=vec_flag(flag_index);
            if egg==1;
                [GYworst, gworst] = max(fitness_m);
                Xnewm(gworst,:)=lb+rand*(ub-lb);%eq.(19)
                [GYworst, gworst] = max(fitness_f);
                Xnewf(gworst,:)=lb+rand*(ub-lb);%eq.(20)
            end
           end
    else


         random_num=rand();
           if random_num<phasethree_acc_pro(1,1)
   if i<=N/2
        for j=1:1:dim
            rand_leader_index = floor(Nm*rand()+1);
            X_randm = Xm(rand_leader_index, :);
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            Am=exp(-fitness_m(rand_leader_index)/(fitness_m(i)+eps));%eq.(7)
            Xnewm(i,j)=X_randm(j)+Flag*C2*Am*((ub(j)-lb(j))*rand+lb(j));%eq.(6)
        end
   else
        for j=1:1:dim
            nu=round(i/2);
            rand_leader_index = floor(Nf*rand()+1);
            X_randf = Xf(rand_leader_index, :);
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            Af=exp(-fitness_f(rand_leader_index)/(fitness_f(nu)+eps));%eq.(9)
            Xnewf(nu,j)=X_randf(j)+Flag*C2*Af*((ub(j)-lb(j))*rand+lb(j));%eq.(8)
        end
   end
  
          elseif random_num>phasethree_acc_pro(1,1) &&random_num<phasethree_acc_pro(1,2)

       if i<=N/2
      
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            for j=1:1:dim
                Xnewm(i,j)=Xfood(j)+C3*Flag*Temp*rand*(Xfood(j)-Xm(i,j));%eq.(10)
            end
       
       else
            flag_index = floor(2*rand()+1);
            Flag=vec_flag(flag_index);
            for j=1:1:dim
                 nu=round(i/2);
                Xnewf(nu,j)=Xfood(j)+Flag*C3*Temp*rand*(Xfood(j)-Xf(nu,j));%eq.(10)
            end
       end
        elseif random_num>phasethree_acc_pro(1,2) &&random_num<phasethree_acc_pro(1,3)
        
  if i<=N/2
                for j=1:1:dim
                    FM=exp(-(fitnessBest_f)/(fitness_m(i)+eps));%eq.(13)
                    Xnewm(i,j)=Xm(i,j) +C3*FM*rand*(Q*Xbest_f(j)-Xm(i,j));%eq.(11)
                    
                end
  else
           
                for j=1:1:dim
                     nu=round(i/2);
                    FF=exp(-(fitnessBest_m)/(fitness_f(nu)+eps));%eq.(14)
                    Xnewf(nu,j)=Xf(nu,j)+C3*FF*rand*(Q*Xbest_m(j)-Xf(nu,j));%eq.(12)
                end
  end   
         elseif random_num>phasethree_acc_pro(1,3) &&random_num<phasethree_acc_pro(1,4)
            if i<N/2
                for j=1:1:dim
                    Mm=exp(-fitness_f(i)/(fitness_m(i)+eps));%eq.(17)
                    Xnewm(i,j)=Xm(i,j) +C3*rand*Mm*(Q*Xf(i,j)-Xm(i,j));%eq.(15
                end
            
            else
                for j=1:1:dim
                     nu=round(i/2);
                    Mf=exp(-fitness_m(nu)/(fitness_f(nu)+eps));%eq.(18)
                    Xnewf(nu,j)=Xf(nu,j) +C3*rand*Mf*(Q*Xm(nu,j)-Xf(nu,j));%eq.(16)
                end

            end

 flag_index = floor(2*rand()+1);
            egg=vec_flag(flag_index);
            if egg==1;
                [GYworst, gworst] = max(fitness_m);
                Xnewm(gworst,:)=lb+rand*(ub-lb);%eq.(19)
                [GYworst, gworst] = max(fitness_f);
                Xnewf(gworst,:)=lb+rand*(ub-lb);%eq.(20)
            end
           end
    end
end
           
   
    for j=1:Nm
        j
         Flag4ub=Xnewm(j,:)>ub(j);
         Flag4lb=Xnewm(j,:)<lb(j);
        Xnewm(j,:)=(Xnewm(j,:).*(~(Flag4ub+Flag4lb)))+ub(j).*Flag4ub+lb(j).*Flag4lb;
        y = feval(fobj,Xnewm(j,:));
        if y<fitness_m(j)
            fitness_m(j)=y;
            Xm(j,:)= Xnewm(j,:);
        end
    end
    
    [Ybest1,gbest1] = min(fitness_m);
    
    for j=1:Nf
         Flag4ub=Xnewf(j,:)>ub;
         Flag4lb=Xnewf(j,:)<lb;
        Xnewf(j,:)=(Xnewf(j,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        y = feval(fobj,Xnewf(j,:));
        if y<fitness_f(j)
            fitness_f(j)=y;
            Xf(j,:)= Xnewf(j,:);
        end
    end
    
    [Ybest2,gbest2] = min(fitness_f);
    
    if Ybest1<fitnessBest_m
        Xbest_m = Xm(gbest1,:);
        fitnessBest_m=Ybest1;
    end
    if Ybest2<fitnessBest_f
        Xbest_f = Xf(gbest2,:);
        fitnessBest_f=Ybest2;
        
    end
    if Ybest1<Ybest2
        gbest_t(t)=min(Ybest1);
    else
        gbest_t(t)=min(Ybest2);
        
    end
    if fitnessBest_m<fitnessBest_f
        GYbest=fitnessBest_m;
        Xfood=Xbest_m;
    else
        GYbest=fitnessBest_f;
        Xfood=Xbest_f;
    end
    
end
fval = GYbest;


function accumulative_probability=calculate(percentage)
phase_percentage=percentage;
phase_probability=zeros(1,4);
accumulative_probability=zeros(1,4);
accumulative=0;
for m=1:4
   phase_probability(1,m)= phase_percentage(1,m)/sum(phase_percentage);
end

  
for n=1:4
    accumulative=accumulative+phase_probability(1,n);
    accumulative_probability(1,n)=accumulative;
end
end
end





