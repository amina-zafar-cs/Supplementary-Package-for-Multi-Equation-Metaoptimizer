%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TIKI TAKA ALGORITHM (TTA)
% Developed by Mohd Fadzil Faisae Ab Rashid
% Faculty of Mechanical Engineering,
% Universiti Malaysia Pahang, Malaysia.
% Email: ffaisae@ump.edu.my
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function[best_fit,best_pos]=TTA1(player_no,max_iter,lb ,ub,dim,fobj,p1,p2,p3)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
phaseone_percentage=zeros(1,3);
phasetwo_percentage=zeros(1,3);
phasethree_percentage=zeros(1,3);
phaseone_percentage(1,:)=p1(1,:);
phasetwo_percentage(1,:)=p2(1,:);
phasethree_percentage(1,:)=p3(1,:);


phaseone_acc_pro=calculate(phaseone_percentage);
phasetwo_acc_pro=calculate(phasetwo_percentage);
phasethree_acc_pro=calculate(phasethree_percentage);




lb=ones(1,dim).*(lb);
ub=ones(1,dim).*(ub);
%Generate Initial Player Position
Player_pos = [];
for i = 1:dim
    minim = lb(i); maxim = ub(i);
    Player_pos = [Player_pos ((maxim-minim).*rand(1,player_no) + minim)'];

end


best_fit=inf;
best_pos=zeros(1,dim);
nkeyplayer = round(0.1*player_no); %Number of keyplayer = 10%
if nkeyplayer < 3
    nkeyplayer = 3;
end
keyplayer = zeros(nkeyplayer,1+dim); %[fit1 pos1;fit2 pos2;fit3 pos3]
keyplayer(1:nkeyplayer,1)=inf;

%Evaluate Initial Position
for i=1:player_no
    Player_fitness(1,i) = fobj(Player_pos(i,:));
end
All_pos = Player_pos;
All_fitness = Player_fitness;
Ball_pos=Player_pos; Ball_fitness=Player_fitness;

%Set coefficients c1, c2, c3 and prob_lost
coef1 = 1.5; coef2 = 2.5; coef3 = 1.2; prob_lost = 0.3;

%Main Loop
for iter=1:max_iter
    %Identify key players (top nkeyplayers)
    [fitness_sorted1 I]=sort(Player_fitness);
    sorted_population1=Player_pos(I,:);
    fitness_sorted = fitness_sorted1(1:player_no);
    sorted_population = sorted_population1(1:player_no,:);
    top_cbest = [fitness_sorted(1:nkeyplayer)' sorted_population(1:nkeyplayer,:)];

    %Update History/Key players
    for k=1:nkeyplayer
        for m = 1:nkeyplayer
            if top_cbest(k,1)< keyplayer(m,1)
                keyplayer(m,:)=top_cbest(k,:);
                break
            end
        end
    end

    best_fit = keyplayer(1,1);
    best_pos = keyplayer(1,2:end);
    convergence(iter,1) = best_fit;



    %UPDATE BALL POSITION
    for i = 1:player_no
        if i == 1
            ip = player_no;
        else
            ip = i-1;
        end
        a=rand(1,dim);
        if iter<max_iter/3
            random_num=rand();
            if random_num<phaseone_acc_pro(1,1)


                Ball_pos(i,:) = a.*(Player_pos(ip,:) - Player_pos(i,:)) + Player_pos(i,:);

            elseif random_num>phaseone_acc_pro(1,1) &&random_num<phaseone_acc_pro(1,2)
                Ball_pos(i,:) = Player_pos(i,:) - (coef1+a).*(Player_pos(ip,:) - Player_pos(i,:));
            else
                Ball_pos(i,:) = Player_pos(i,:) + (coef1+a).*(Player_pos(ip,:) - Player_pos(i,:));
            end

        elseif iter>max_iter/3&&iter<2*max_iter/3     %%%Phase 2
            random_num=rand();
            if random_num<phasetwo_acc_pro(1,1)

                Ball_pos(i,:) = a.*(Player_pos(ip,:) - Player_pos(i,:)) + Player_pos(i,:);

            elseif random_num>phasetwo_acc_pro(1,1) &&random_num<phasetwo_acc_pro(1,2)
                Ball_pos(i,:) = Player_pos(i,:) - (coef1+a).*(Player_pos(ip,:) - Player_pos(i,:));
            else
                Ball_pos(i,:) = Player_pos(i,:) + (coef1+a).*(Player_pos(ip,:) - Player_pos(i,:));
            end
        else              %%Phase 3
            random_num=rand();
            if random_num<phasethree_acc_pro(1,1)

                Ball_pos(i,:) = a.*(Player_pos(ip,:) - Player_pos(i,:)) + Player_pos(i,:);

            elseif random_num>phasethree_acc_pro(1,1) &&random_num<phasethree_acc_pro(1,2)
                Ball_pos(i,:) = Player_pos(i,:) - (coef1+a).*(Player_pos(ip,:) - Player_pos(i,:));
            else
                Ball_pos(i,:) = Player_pos(i,:) + (coef1+a).*(Player_pos(ip,:) - Player_pos(i,:));
            end

        end

        %Makesure the new position within bound
        Flag4ub=Ball_pos(i,:)>ub;
        Flag4lb=Ball_pos(i,:)<lb;
        Ball_pos(i,:)=(Ball_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    end
    %UPDATE PLAYER POS
    for i=1:player_no
        b = rand(1,dim);
        c = rand(1,dim);
        d = rand(1,dim);
        r = (1-(iter/max_iter))*coef2;
        s = (1-(iter/max_iter))*coef3;
        kp = randi(nkeyplayer); %randomly choose keyplayer
        if i == 1
            Player_pos (i,:) = b.*(mean(Player_pos(1:2,:)));
        else
            Player_pos (i,:) = b.*r.*(Ball_pos(i,:)-Player_pos(i,:)) + ...
                d.*s.*(keyplayer(kp,2:end) - Player_pos(i,:)) + Player_pos(i,:);
        end
        %Makesure the new position within bound
        Flag4ub=Player_pos(i,:)>ub;
        Flag4lb=Player_pos(i,:)<lb;
        Player_pos(i,:)=(Player_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;

        %Evaluate new player position fitness
        Player_fitness(1,i) = fobj(Player_pos(i,:));
    end

end
best_pos;
best_fit;


% To calculate the accumulative probability of equations in particular phase
    function accumulative_probability=calculate(percentage)
        phase_percentage=percentage;
        phase_probability=zeros(1,3);
        accumulative_probability=zeros(1,3);
        accumulative=0;
        for m1=1:3
            phase_probability(1,m1)= phase_percentage(1,m1)/sum(phase_percentage);
        end


        for n=1:3
            accumulative=accumulative+phase_probability(1,n);
            accumulative_probability(1,n)=accumulative;
        end
    end
end