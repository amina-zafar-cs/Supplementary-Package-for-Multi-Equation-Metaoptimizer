

clear all
clc

format long
%Plz enter the algorthm number here, 1 for AO, 2 for ARO, 3 for HHO
%4 for JFS, 5 for SCA, 6 for SO, 7 for TTA, 8 for WOA
Algorithm_no=8;
SearchAgents_no=10; % Number of search agents   
Max_iteration=200; % Maximum number of iterations

lb=0;
ub=100;
if(Algorithm_no==1)
    dim=12;


    [Best_score,Best_pos,Convergence_curve]=MPA_AO(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);

elseif(Algorithm_no==2)

        dim=6;


    [Best_score,Best_pos,Convergence_curve]=MPA_ARO(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);

elseif(Algorithm_no==3)

        dim=18;


    [Best_score,Best_pos,Convergence_curve]=MPA_HHO(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);

elseif(Algorithm_no==4)

        dim=9;


    [Best_score,Best_pos,Convergence_curve]=MPA_JFS(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);

elseif(Algorithm_no==5)

        dim=6;


    [Best_score,Best_pos,Convergence_curve]=MPA_SCA(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);

    elseif(Algorithm_no==6)

        dim=12;


    [Best_score,Best_pos,Convergence_curve]=MPA_SO(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);
    
    elseif(Algorithm_no==7)

        dim=9;


    [Best_score,Best_pos,Convergence_curve]=MPA_TTA(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);


    elseif(Algorithm_no==8)

        dim=9;


    [Best_score,Best_pos,Convergence_curve]=MPA_WOA(SearchAgents_no,Max_iteration,lb,ub,dim);

    display(['The best solution obtained by MPA is : ', num2str(Best_pos,10)]);
    display(['The best optimal value of the objective function found by MPA is : ', num2str(Best_score,10)]);

    end
