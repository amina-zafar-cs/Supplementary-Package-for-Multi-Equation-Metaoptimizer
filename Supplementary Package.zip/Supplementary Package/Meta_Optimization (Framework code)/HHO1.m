% Developed in MATLAB R2013b
% Source codes demo version 1.0
% _____________________________________________________

% Main paper:
% Harris hawks optimization: Algorithm and applications
% Ali Asghar Heidari, Seyedali Mirjalili, Hossam Faris, Ibrahim Aljarah, Majdi Mafarja, Huiling Chen
% Future Generation Computer Systems,
% DOI: https://doi.org/10.1016/j.future.2019.02.028
% https://www.sciencedirect.com/science/article/pii/S0167739X18313530
% _____________________________________________________

% You can run the HHO code online at codeocean.com  https://doi.org/10.24433/CO.1455672.v1
% You can find the HHO code at https://github.com/aliasghar68/Harris-hawks-optimization-Algorithm-and-applications-.git
% _____________________________________________________

%  Author, inventor and programmer: Ali Asghar Heidari,
%  PhD research intern, Department of Computer Science, School of Computing, National University of Singapore, Singapore
%  Exceptionally Talented Ph. DC funded by Iran's National Elites Foundation (INEF), University of Tehran
%  03-03-2019

%  Researchgate: https://www.researchgate.net/profile/Ali_Asghar_Heidari

%  e-Mail: as_heidari@ut.ac.ir, aliasghar68@gmail.com,
%  e-Mail (Singapore): aliasgha@comp.nus.edu.sg, t0917038@u.nus.edu
% _____________________________________________________
%  Co-author and Advisor: Seyedali Mirjalili
%
%         e-Mail: ali.mirjalili@gmail.com
%                 seyedali.mirjalili@griffithuni.edu.au
%
%       Homepage: http://www.alimirjalili.com
% _____________________________________________________
%  Co-authors: Hossam Faris, Ibrahim Aljarah, Majdi Mafarja, and Hui-Ling Chen

%       Homepage: http://www.evo-ml.com/2019/03/02/hho/
% _____________________________________________________
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Harris's hawk optimizer: In this algorithm, Harris' hawks try to catch the rabbit.

% T: maximum iterations, N: populatoin size, CNVG: Convergence curve
% To run HHO: [Rabbit_Energy,Rabbit_Location,CNVG]=HHO(N,T,lb,ub,dim,fobj)

function [Rabbit_Energy,Rabbit_Location,CNVG]=HHO1(N,T,lb,ub,dim,fobj,p1,p2,p3)
phaseone_percentage=zeros(1,6);
phasetwo_percentage=zeros(1,6);
phasethree_percentage=zeros(1,6);
phaseone_percentage(1,:)=p1(1,:);
phasetwo_percentage(1,:)=p2(1,:);
phasethree_percentage(1,:)=p3(1,:);
%  phaseone_percentage=[18.63290715	16.74192828	74.14341735	82.60949458	75.21708088	91.03434468];
% %
%  phasetwo_percentage=[24.57150933	77.83776444	74.14341735	82.60949458	75.21708088	91.03434468];
%  phasethree_percentage=[5.378276461	0.065862947	74.14341735	82.60949458	75.21708088	91.03434468];

phaseone_acc_pro=calculate(phaseone_percentage);
phasetwo_acc_pro=calculate(phasetwo_percentage);
phasethree_acc_pro=calculate(phasethree_percentage);


Rabbit_Location=zeros(1,dim);
Rabbit_Energy=inf;

%Initialize the locations of Harris' hawks
X=initialization(N,dim,ub,lb);

CNVG=zeros(1,T);

t=0; % Loop counter

while t<T
    for i=1:size(X,1)
        % Check boundries
        FU=X(i,:)>ub;FL=X(i,:)<lb;X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
        % fitness of locations
        fitness=fobj(X(i,:));
        % Update the location of Rabbit
        if fitness<Rabbit_Energy
            Rabbit_Energy=fitness;
            Rabbit_Location=X(i,:);
        end
    end

    E1=2*(1-(t/T)); % factor to show the decreaing energy of rabbit
    % Update the location of Harris' hawks
    for i=1:size(X,1)
        E0=2*rand()-1; %-1<E0<1
        Escaping_Energy=E1*(E0);  % escaping energy of rabbit

        %         if abs(Escaping_Energy)>=1

        if t<T/3                %%Phase 1
            q=rand();
            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index, :);
            random_num=rand();
            if random_num<phaseone_acc_pro(1,1)

                X(i,:)=X_rand-rand()*abs(X_rand-2*rand()*X(i,:));
            elseif random_num>phaseone_acc_pro(1,1) &&random_num<phaseone_acc_pro(1,2)

                X(i,:)=(Rabbit_Location(1,:)-mean(X))-rand()*((ub-lb)*rand+lb);



            elseif random_num>phaseone_acc_pro(1,2) &&random_num<phaseone_acc_pro(1,3)
                X(i,:)=(Rabbit_Location)-Escaping_Energy*abs(Rabbit_Location-X(i,:));

            elseif random_num>phaseone_acc_pro(1,3) &&random_num<phaseone_acc_pro(1,4)

                Jump_strength=2*(1-rand()); % random jump strength of the rabbit
                X(i,:)=(Rabbit_Location-X(i,:))-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));




            elseif random_num>phaseone_acc_pro(1,4) &&random_num<phaseone_acc_pro(1,5)
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));

                if fobj(X1)<fobj(X(i,:)) % improved move?
                    X(i,:)=X1;
                else % hawks perform levy-based short rapid dives around the rabbit
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:))+rand(1,dim).*Levy(dim);
                    if (fobj(X2)<fobj(X(i,:))) % improved move?
                        X(i,:)=X2;
                    end
                end
            end


        elseif random_num>phaseone_acc_pro(1,5) &&random_num<phaseone_acc_pro(1,6)
            Jump_strength=2*(1-rand());
            X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X));

            if fobj(X1)<fobj(X(i,:)) % improved move?
                X(i,:)=X1;
            else
                X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X))+rand(1,dim).*Levy(dim);
                if (fobj(X2)<fobj(X(i,:))) % improved move?
                    X(i,:)=X2;
                end
            end
        elseif t>T/3 && t<2*T/3          %% Phase 2
            q=rand();


            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index, :);
            random_num=rand();
            if random_num<phasetwo_acc_pro(1,1)

                X(i,:)=X_rand-rand()*abs(X_rand-2*rand()*X(i,:));
            elseif random_num>phasetwo_acc_pro(1,1) &&random_num<phasetwo_acc_pro(1,2)

                X(i,:)=(Rabbit_Location(1,:)-mean(X))-rand()*((ub-lb)*rand+lb);

            elseif random_num>phasetwo_acc_pro(1,2) &&random_num<phasetwo_acc_pro(1,3)
                X(i,:)=(Rabbit_Location)-Escaping_Energy*abs(Rabbit_Location-X(i,:));

            elseif random_num>phasetwo_acc_pro(1,3) &&random_num<phasetwo_acc_pro(1,4)

                Jump_strength=2*(1-rand()); % random jump strength of the rabbit
                X(i,:)=(Rabbit_Location-X(i,:))-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));


            elseif random_num>phasetwo_acc_pro(1,4) &&random_num<phasetwo_acc_pro(1,5)
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));

                if fobj(X1)<fobj(X(i,:)) % improved move?
                    X(i,:)=X1;
                else % hawks perform levy-based short rapid dives around the rabbit
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:))+rand(1,dim).*Levy(dim);
                    if (fobj(X2)<fobj(X(i,:))) % improved move?
                        X(i,:)=X2;
                    end
                end
            elseif random_num>phasetwo_acc_pro(1,5) &&random_num<phasetwo_acc_pro(1,6)
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X));

                if fobj(X1)<fobj(X(i,:)) % improved move?
                    X(i,:)=X1;
                else % Perform levy-based short rapid dives around the rabbit
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X))+rand(1,dim).*Levy(dim);
                    if (fobj(X2)<fobj(X(i,:))) % improved move?
                        X(i,:)=X2;
                    end
                end
            end
        else           %% Phase 3
            q=rand();


            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index, :);
            random_num=rand();
            if random_num<phasethree_acc_pro(1,1)

                X(i,:)=X_rand-rand()*abs(X_rand-2*rand()*X(i,:));
            elseif random_num>phasethree_acc_pro(1,1) &&random_num<phasethree_acc_pro(1,2)

                X(i,:)=(Rabbit_Location(1,:)-mean(X))-rand()*((ub-lb)*rand+lb);

            elseif random_num>phasethree_acc_pro(1,2) &&random_num<phasethree_acc_pro(1,3)
                X(i,:)=(Rabbit_Location)-Escaping_Energy*abs(Rabbit_Location-X(i,:));

            elseif random_num>phasethree_acc_pro(1,3) &&random_num<phasethree_acc_pro(1,4)

                Jump_strength=2*(1-rand()); % random jump strength of the rabbit
                X(i,:)=(Rabbit_Location-X(i,:))-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));

            elseif random_num>phasethree_acc_pro(1,4) &&random_num<phasethree_acc_pro(1,5)
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));

                if fobj(X1)<fobj(X(i,:)) % improved move?
                    X(i,:)=X1;
                else % hawks perform levy-based short rapid dives around the rabbit
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:))+rand(1,dim).*Levy(dim);
                    if (fobj(X2)<fobj(X(i,:))) % improved move?
                        X(i,:)=X2;
                    end
                end

            elseif random_num>phasethree_acc_pro(1,5) &&random_num<phasethree_acc_pro(1,6)
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X));

                if fobj(X1)<fobj(X(i,:)) % improved move?
                    X(i,:)=X1;
                else % Perform levy-based short rapid dives around the rabbit
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X))+rand(1,dim).*Levy(dim);
                    if (fobj(X2)<fobj(X(i,:))) % improved move?
                        X(i,:)=X2;
                    end
                end
            end


        end
    end

    t=t+1;
    CNVG(t)=Rabbit_Energy;

end
%% To calculate the accumulative probability of equations in particular phase
    function accumulative_probability=calculate(percentage)
        phase_percentage=percentage;
        phase_probability=zeros(1,6);
        accumulative_probability=zeros(1,6);
        accumulative=0;
        for m=1:6
            phase_probability(1,m)= phase_percentage(1,m)/sum(phase_percentage);
        end


        for n=1:6
            accumulative=accumulative+phase_probability(1,n);
            accumulative_probability(1,n)=accumulative;
        end
    end

end

% ___________________________________
function o=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;v=randn(1,d);step=u./abs(v).^(1/beta);
o=step;
end

