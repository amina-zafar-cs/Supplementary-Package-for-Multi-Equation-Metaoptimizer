
function result_stored  =getresults_HHO(comb)




p1=zeros(1,6);
p2=zeros(1,6);
p3=zeros(1,6);
p1=comb(1,1:6);
p2=comb(1,7:12);
p3=comb(1,13:18);

       display(['****comb:  ', '    ',num2str(comb),'    ',num2str(p1(1,1)),'    ',num2str(p1(1,2)),'    ',num2str(p1(1,3)),'    ',num2str(p1(1,4)),'    ',num2str(p1(1,5)),'    ',num2str(p1(1,6)),'    ',num2str(p2(1,1)),'    ',num2str(p2(1,2)),'    ',num2str(p2(1,3)),'    ',num2str(p2(1,4)),'    ',num2str(p2(1,5)),'    ',num2str(p2(1,6)),'    ',num2str(p3(1,1)),'    ',num2str(p3(1,2)),'    ',num2str(p3(1,3)),'    ',num2str(p3(1,4)),'    ',num2str(p3(1,5)),'    ',num2str(p3(1,6)),'*****']);

            global penalty
           

            SearchAgents_no=35;% Number of search agents

            
  result_stored=zeros(14,1);
            Max_iteration=1000;

                for fn = 1:14
                   

                    Function_name=strcat('F',num2str(fn));

                        [lb,ub,dim,fobj]=Funtions_optimal_difference(Function_name);

                    runs=1;
                    Best_score_T = zeros(runs,1);
                    Best_pos_T=zeros(runs,dim);
                     for run=1:runs
                    [Best_score,Best_pos,cg_curve]=HHO1(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,p1,p2,p3);
                   
                    Best_score_T(run) = Best_score;
                     end
                      Best_Score_Mean = mean(Best_score_T);
                    display(['Function:  ', num2str(fn),'  ','cost:  ', num2str(  Best_Score_Mean)]);
               result_stored(fn,1)=  Best_Score_Mean;

                end
           

end




